# A.K Journal v1
A simple TradeZella-style trading journal starter app.
Open the project in Android Studio and build APK with:
Build > Build App Bundle(s) / APK(s) > Build APK(s)
