package com.akjournal

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight

data class Trade(val symbol:String,val side:String,val pnl:Double,val rr:String,val note:String)

class MainActivity: ComponentActivity(){
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{AKJournal()}}
}

@Composable
fun AKJournal(){
 var tab by remember{mutableStateOf(0)}
 var show by remember{mutableStateOf(false)}
 var symbol by remember{mutableStateOf("")}
 var pnl by remember{mutableStateOf("")}
 var rr by remember{mutableStateOf("")}
 var note by remember{mutableStateOf("")}
 val trades= remember{mutableStateListOf(
   Trade("XAUUSD","BUY",27.0,"1:2","London liquidity sweep"),
   Trade("NAS100","SELL",-17.0,"1:1","Stopped at resistance")
 )}
 val total=trades.sumOf{it.pnl}
 val wins=trades.count{it.pnl>0}
 val wr=if(trades.isEmpty())0 else wins*100/trades.size

 MaterialTheme(colorScheme=darkColorScheme(
   background=Color(0xFF0E1014),surface=Color(0xFF171A21),primary=Color(0xFF7C9CFF)
 )){
  Scaffold(bottomBar={NavigationBar{
    NavigationBarItem(tab==0,{tab=0},{Text("Dashboard")})
    NavigationBarItem(tab==1,{tab=1},{Text("Trades")})
  }}){pad->
   if(tab==0) Dashboard(pad,total,wr,trades.size){show=true}
   else Trades(pad,trades){show=true}
  }
  if(show) AlertDialog(onDismissRequest={show=false},confirmButton={
    TextButton(onClick={
      val p=pnl.toDoubleOrNull()?:0.0
      trades.add(Trade(symbol.ifBlank{"XAUUSD"},"BUY",p,rr.ifBlank{"1:2"},note))
      symbol="";pnl="";rr="";note="";show=false
    }){Text("SAVE")}
  },dismissButton={TextButton(onClick={show=false}){Text("CANCEL")}},
   title={Text("Add Trade")},text={
    Column{ OutlinedTextField(symbol,{symbol=it},label={Text("Symbol")})
      OutlinedTextField(pnl,{pnl=it},label={Text("P/L")})
      OutlinedTextField(rr,{rr=it},label={Text("Risk : Reward")})
      OutlinedTextField(note,{note=it},label={Text("Notes")})
    }
   })
 }
}

@Composable fun Dashboard(pad:PaddingValues,total:Double,wr:Int,count:Int,add:()->Unit){
 Column(Modifier.padding(pad).padding(18.dp)){
  Text("A.K JOURNAL",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
  Text("Your trading performance",color=Color.LightGray)
  Spacer(Modifier.height(20.dp))
  Card(Modifier.fillMaxWidth()){Column(Modifier.padding(18.dp)){
    Text("TOTAL P/L",color=Color.Gray);Text("$%.2f".format(total),style=MaterialTheme.typography.headlineLarge,fontWeight=FontWeight.Bold)
  }}
  Spacer(Modifier.height(12.dp))
  Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){
   Stat("WIN RATE","$wr%");Stat("TRADES","$count")
  }
  Spacer(Modifier.height(18.dp))
  Button(add,Modifier.fillMaxWidth()){Text("+ ADD TRADE")}
 }
}
@Composable fun Stat(a:String,b:String){Card(Modifier.weight(1f)){Column(Modifier.padding(16.dp)){Text(a,color=Color.Gray);Text(b,fontWeight=FontWeight.Bold)}}}

@Composable fun Trades(pad:PaddingValues,trades:List<Trade>,add:()->Unit){
 Column(Modifier.padding(pad).padding(18.dp)){
  Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){
   Text("MY TRADES",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
   TextButton(add){Text("+ ADD")}
  }
  LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){
   items(trades){t->Card(Modifier.fillMaxWidth()){Row(Modifier.padding(16.dp),Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){
    Column{Text(t.symbol,fontWeight=FontWeight.Bold);Text("${t.side} • RR ${t.rr}");Text(t.note,color=Color.Gray)}
    Text("$%.2f".format(t.pnl),fontWeight=FontWeight.Bold)
   }}}
  }
 }
}
